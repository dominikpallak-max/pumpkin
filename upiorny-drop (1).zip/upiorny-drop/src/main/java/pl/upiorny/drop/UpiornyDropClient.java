package pl.upiorny.drop;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtOps;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.*;
import java.util.regex.*;

public class UpiornyDropClient implements ClientModInitializer {
    private static final Pattern CHEST = Pattern.compile("Upiorna Skrzynia.*?Poziom:?\\s*(\\d+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern ID = Pattern.compile("[a-z0-9_.-]+:[a-z0-9_./-]+");
    private static final Map<String, List<Text>> CACHE = new HashMap<>();

    /** Zapisuje caly ItemStack (wraz z ukrytymi danymi) jako tekst. */
    static String encode(ItemStack stack) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return null;
        var ops = mc.world.getRegistryManager().getOps(NbtOps.INSTANCE);
        return ItemStack.CODEC.encodeStart(ops, stack).result().map(Object::toString).orElse(null);
    }

    /** Szuka w danych skrzyni ID przedmiotow (poza sama skrzynia) i zwraca ich nazwy. */
    static List<Text> findItems(String data) {
        List<Text> out = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        Matcher m = ID.matcher(data);
        while (m.find()) {
            String s = m.group();
            if (s.equals("minecraft:pumpkin") || !seen.add(s)) continue;
            Identifier id = Identifier.tryParse(s);
            if (id != null && Registries.ITEM.containsId(id)) {
                out.add(Text.literal("\u00a7a  \u2022 ").append(Registries.ITEM.get(id).getName()));
            }
        }
        return out;
    }

    @Override
    public void onInitializeClient() {
        DropConfig.load();

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("minecraftserver")
                .executes(ctx -> {
                    MinecraftClient mc = ctx.getSource().getClient();
                    mc.send(() -> mc.setScreen(new ToggleScreen()));
                    return 1;
                })
                .then(ClientCommandManager.literal("dump").executes(ctx -> {
                    MinecraftClient mc = ctx.getSource().getClient();
                    String s = encode(mc.player.getMainHandStack());
                    if (s == null) s = "blad";
                    mc.keyboard.setClipboard(s);
                    mc.player.sendMessage(Text.literal(s), false);
                    mc.player.sendMessage(Text.literal("\u00a7aSkopiowano do schowka."), false);
                    return 1;
                }))));

        ItemTooltipCallback.EVENT.register((stack, context, type, lines) -> {
            if (!DropConfig.INSTANCE.enabled || stack.isEmpty()) return;
            if (!CHEST.matcher(stack.getName().getString()).find()) return;

            String data = encode(stack);
            if (data == null) return;
            List<Text> items = CACHE.computeIfAbsent(data, UpiornyDropClient::findItems);

            int idx = lines.size();
            for (int i = 1; i < lines.size(); i++) {
                if (lines.get(i).getString().startsWith("minecraft:")) { idx = i; break; }
            }
            lines.add(idx++, Text.literal(""));
            if (items.isEmpty()) {
                lines.add(idx, Text.literal("\u00a77Brak danych o dropie w tej skrzyni"));
            } else {
                lines.add(idx++, Text.literal("\u00a76Wypadnie ze skrzyni:"));
                for (Text t : items) lines.add(idx++, t);
            }
        });
    }
}
