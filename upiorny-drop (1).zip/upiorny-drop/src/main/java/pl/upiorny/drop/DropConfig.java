package pl.upiorny.drop;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.*;

public class DropConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("upiorny_drop.json");

    public boolean enabled = true;
    public static DropConfig INSTANCE = new DropConfig();

    public static void load() {
        try {
            if (Files.exists(PATH)) {
                DropConfig c = GSON.fromJson(Files.readString(PATH), DropConfig.class);
                if (c != null) { INSTANCE = c; return; }
            }
        } catch (Exception e) { e.printStackTrace(); }
        INSTANCE = new DropConfig();
        save();
    }

    public static void save() {
        try { Files.writeString(PATH, GSON.toJson(INSTANCE)); } catch (Exception e) { e.printStackTrace(); }
    }
}
