package pl.pumpkin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.InteractionEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Locale;

/**
 * KillAura bije WYLACZNIE byty typu minecraft:interaction (entity.minecraft.interaction).
 * Gracze, moby i reszta sa calkowicie ignorowane - nawet jak obok stoi tlum ludzi.
 * Opcjonalnie mozna zawezic po nazwie bytu (puste = kazdy interaction w zasiegu).
 */
public final class KillAura {

	private static int cooldown = 0;

	private KillAura() {}

	public static void tick(MinecraftClient mc) {
		if (!PumpkinMod.killaura) return;
		ClientPlayerEntity player = mc.player;
		if (player == null || mc.world == null || mc.interactionManager == null) return;
		if (!player.isAlive() || player.isSpectator()) return;

		if (cooldown > 0) {
			cooldown--;
			return;
		}

		Vec3d eye = player.getEyePos();
		double maxSq = (double) PumpkinMod.kaRange * PumpkinMod.kaRange;
		String filter = PumpkinMod.kaName.trim().toLowerCase(Locale.ROOT);

		Entity best = null;
		double bestSq = Double.MAX_VALUE;

		for (Entity e : mc.world.getEntities()) {
			if (!(e instanceof InteractionEntity)) continue;       // TYLKO interaction
			if (!filter.isEmpty()
				&& !e.getName().getString().toLowerCase(Locale.ROOT).contains(filter)) continue;

			double d = distSqToBox(eye, e.getBoundingBox());
			if (d > maxSq || d >= bestSq) continue;
			best = e;
			bestSq = d;
		}

		if (best != null) {
			mc.interactionManager.attackEntity(player, best);
			player.swingHand(Hand.MAIN_HAND);
			cooldown = Math.max(0, PumpkinMod.kaDelay - 1);
		}
	}

	private static double distSqToBox(Vec3d p, Box b) {
		double dx = Math.max(Math.max(b.minX - p.x, 0), p.x - b.maxX);
		double dy = Math.max(Math.max(b.minY - p.y, 0), p.y - b.maxY);
		double dz = Math.max(Math.max(b.minZ - p.z, 0), p.z - b.maxZ);
		return dx * dx + dy * dy + dz * dz;
	}
}
