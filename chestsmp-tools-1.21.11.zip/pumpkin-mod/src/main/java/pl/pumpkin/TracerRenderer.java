package pl.pumpkin;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.util.Locale;

/**
 * Rysowanie tracerow do armor standow o nazwie "Niespodzianka".
 * UWAGA: system renderowania w 1.21.9-1.21.11 jest calkiem nowy; tylko ta klasa
 * zalezy od API renderowania. Gdyby sie nie skompilowala - to tu trzeba poprawic.
 */
public final class TracerRenderer {

	private static final int R = 170, G = 0, B = 255, A = 255;     // fiolet
	private static final int TEXT_COLOR = 0xFFAA00FF;

	private TracerRenderer() {}

	public static void init() {
		WorldRenderEvents.LAST.register(TracerRenderer::render);
	}

	private static boolean matches(Entity e) {
		if (!(e instanceof ArmorStandEntity)) return false;
		return e.getName().getString().toLowerCase(Locale.ROOT)
			.contains(PumpkinMod.targetName.toLowerCase(Locale.ROOT));
	}

	private static void render(WorldRenderContext context) {
		if (!PumpkinMod.tracers) return;
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.world == null || mc.player == null) return;

		MatrixStack matrices = context.matrixStack();
		VertexConsumerProvider consumers = context.consumers();
		if (matrices == null || consumers == null) return;

		Camera camera = context.camera();
		Vec3d camPos = camera.getCameraPos();
		float tickDelta = context.tickCounter().getTickProgress(false);

		// start: srodek ekranu
		Vec3d look = Vec3d.fromPolar(camera.getPitch(), camera.getYaw());

		VertexConsumer lines = consumers.getBuffer(RenderLayer.getLines());
		MatrixStack.Entry entry = matrices.peek();
		float w = PumpkinMod.thickness;

		for (Entity e : mc.world.getEntities()) {
			if (!matches(e)) continue;
			Vec3d p = e.getLerpedPos(tickDelta).add(0, e.getHeight() / 2.0, 0).subtract(camPos);
			Vec3d dir = p.subtract(look).normalize();

			lines.vertex(entry, (float) look.x, (float) look.y, (float) look.z)
				.color(R, G, B, A).normal(entry, (float) dir.x, (float) dir.y, (float) dir.z).lineWidth(w);
			lines.vertex(entry, (float) p.x, (float) p.y, (float) p.z)
				.color(R, G, B, A).normal(entry, (float) dir.x, (float) dir.y, (float) dir.z).lineWidth(w);
		}

		// napisy: nazwa + dystans
		TextRenderer tr = mc.textRenderer;
		for (Entity e : mc.world.getEntities()) {
			if (!matches(e)) continue;
			Vec3d rel = e.getLerpedPos(tickDelta).add(0, e.getHeight() + 0.4, 0).subtract(camPos);
			double dist = mc.player.getEntityPos().distanceTo(e.getEntityPos());
			Text text = Text.literal(e.getName().getString() + " §7[" + String.format(Locale.ROOT, "%.1f", dist) + "m]");

			matrices.push();
			matrices.translate(rel.x, rel.y, rel.z);
			matrices.multiply(camera.getRotation());
			float scale = 0.025f * (float) Math.max(1.0, Math.min(5.0, dist / 6.0));
			matrices.scale(-scale, -scale, scale);
			tr.draw(text, -tr.getWidth(text) / 2.0f, 0, TEXT_COLOR, false,
				matrices.peek().getPositionMatrix(), consumers,
				TextRenderer.TextLayerType.SEE_THROUGH, 0x66000000, 0xF000F0);
			matrices.pop();
		}
	}
}
