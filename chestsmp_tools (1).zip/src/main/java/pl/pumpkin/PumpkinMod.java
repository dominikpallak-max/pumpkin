package pl.pumpkin;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public class PumpkinMod implements ClientModInitializer {

	public static boolean tracers = false;
	public static float thickness = 1.0f;
	public static String targetName = "Niespodzianka";

	public static boolean killaura = false;
	public static float kaRange = 3.0f;
	public static int kaDelay = 5;
	public static String kaName = "";

	public static int killauraKey = 75; // K
	public static int tracersKey = 74; // J

	private static final Path CONFIG = FabricLoader.getInstance().getConfigDir().resolve("chestsmp_tools.properties");

	@Override
	public void onInitializeClient() {
		loadConfig();

		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
			dispatcher.register(ClientCommandManager.literal("pumpkin")
				.executes(ctx -> {
					MinecraftClient mc = MinecraftClient.getInstance();
					mc.send(() -> mc.setScreen(new PumpkinScreen()));
					return 1;
				})));

		ClientTickEvents.END_CLIENT_TICK.register(KillAura::tick);
		Keybinds.init();
		ClientTickEvents.END_CLIENT_TICK.register(Keybinds::tick);
		TracerRenderer.init();
	}

	private static void loadConfig() {
		if (!Files.exists(CONFIG)) return;
		try (InputStream in = Files.newInputStream(CONFIG)) {
			Properties p = new Properties();
			p.load(in);
			tracers = Boolean.parseBoolean(p.getProperty("tracers", "false"));
			thickness = Float.parseFloat(p.getProperty("thickness", "1.0"));
			targetName = p.getProperty("name", "Niespodzianka");
			killaura = Boolean.parseBoolean(p.getProperty("killaura", "false"));
			kaRange = Float.parseFloat(p.getProperty("ka_range", "3.0"));
			kaDelay = Integer.parseInt(p.getProperty("ka_delay", "5"));
			kaName = p.getProperty("ka_name", "");
			killauraKey = Integer.parseInt(p.getProperty("key_killaura", "75"));
			tracersKey = Integer.parseInt(p.getProperty("key_tracers", "74"));
		} catch (IOException | NumberFormatException ignored) {
		}
	}

	public static void saveConfig() {
		Properties p = new Properties();
		p.setProperty("tracers", String.valueOf(tracers));
		p.setProperty("thickness", String.valueOf(thickness));
		p.setProperty("name", targetName);
		p.setProperty("killaura", String.valueOf(killaura));
		p.setProperty("ka_range", String.valueOf(kaRange));
		p.setProperty("ka_delay", String.valueOf(kaDelay));
		p.setProperty("ka_name", kaName);
		p.setProperty("key_killaura", String.valueOf(killauraKey));
		p.setProperty("key_tracers", String.valueOf(tracersKey));
		try (OutputStream out = Files.newOutputStream(CONFIG)) {
			p.store(out, "Chest SMP Tools");
		} catch (IOException ignored) {
		}
	}
}
