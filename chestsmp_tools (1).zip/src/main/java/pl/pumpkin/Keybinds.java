package pl.pumpkin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class Keybinds {

	public static final int NONE = -1;
	private static final int MOUSE_BASE = 1000;

	private static boolean killPrev = false;
	private static boolean trPrev = false;

	private Keybinds() {}

	public static void init() {}

	public static boolean isDown(MinecraftClient mc, int key) {
		if (key < 0) return false;
		long w = mc.getWindow().getHandle();
		if (key >= MOUSE_BASE) {
			return GLFW.glfwGetMouseButton(w, key - MOUSE_BASE) == GLFW.GLFW_PRESS;
		}
		return GLFW.glfwGetKey(w, key) == GLFW.GLFW_PRESS;
	}

	/** Zwraca pierwszy wcisniety klawisz / przycisk myszy (bez LPM i PPM) albo NONE. */
	public static int scanPressed(MinecraftClient mc) {
		long w = mc.getWindow().getHandle();
		for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
			if (GLFW.glfwGetKey(w, k) == GLFW.GLFW_PRESS) return k;
		}
		for (int b = 2; b <= 7; b++) {
			if (GLFW.glfwGetMouseButton(w, b) == GLFW.GLFW_PRESS) return MOUSE_BASE + b;
		}
		return NONE;
	}

	public static String keyName(int key) {
		if (key < 0) return "brak";
		if (key >= MOUSE_BASE) return "Mysz " + (key - MOUSE_BASE + 1);
		if (key >= GLFW.GLFW_KEY_F1 && key <= GLFW.GLFW_KEY_F25) return "F" + (key - GLFW.GLFW_KEY_F1 + 1);
		switch (key) {
			case GLFW.GLFW_KEY_SPACE: return "Spacja";
			case GLFW.GLFW_KEY_ENTER: return "Enter";
			case GLFW.GLFW_KEY_TAB: return "Tab";
			case GLFW.GLFW_KEY_BACKSPACE: return "Backspace";
			case GLFW.GLFW_KEY_DELETE: return "Delete";
			case GLFW.GLFW_KEY_INSERT: return "Insert";
			case GLFW.GLFW_KEY_HOME: return "Home";
			case GLFW.GLFW_KEY_END: return "End";
			case GLFW.GLFW_KEY_PAGE_UP: return "PageUp";
			case GLFW.GLFW_KEY_PAGE_DOWN: return "PageDown";
			case GLFW.GLFW_KEY_UP: return "Strzalka gora";
			case GLFW.GLFW_KEY_DOWN: return "Strzalka dol";
			case GLFW.GLFW_KEY_LEFT: return "Strzalka lewo";
			case GLFW.GLFW_KEY_RIGHT: return "Strzalka prawo";
			case GLFW.GLFW_KEY_LEFT_SHIFT: return "L-Shift";
			case GLFW.GLFW_KEY_RIGHT_SHIFT: return "R-Shift";
			case GLFW.GLFW_KEY_LEFT_CONTROL: return "L-Ctrl";
			case GLFW.GLFW_KEY_RIGHT_CONTROL: return "R-Ctrl";
			case GLFW.GLFW_KEY_LEFT_ALT: return "L-Alt";
			case GLFW.GLFW_KEY_RIGHT_ALT: return "R-Alt";
			case GLFW.GLFW_KEY_CAPS_LOCK: return "CapsLock";
			default: break;
		}
		String n = GLFW.glfwGetKeyName(key, 0);
		if (n != null) return n.toUpperCase();
		return "Klawisz " + key;
	}

	public static void tick(MinecraftClient mc) {
		boolean ka = mc.currentScreen == null && isDown(mc, PumpkinMod.killauraKey);
		if (ka && !killPrev) {
			PumpkinMod.killaura = !PumpkinMod.killaura;
			PumpkinMod.saveConfig();
			say(mc, "KillAura: " + (PumpkinMod.killaura ? "§aWŁĄCZONA" : "§cWYŁĄCZONA"));
		}
		killPrev = ka;

		boolean tr = mc.currentScreen == null && isDown(mc, PumpkinMod.tracersKey);
		if (tr && !trPrev) {
			PumpkinMod.tracers = !PumpkinMod.tracers;
			PumpkinMod.saveConfig();
			say(mc, "Tracery: " + (PumpkinMod.tracers ? "§aWŁĄCZONE" : "§cWYŁĄCZONE"));
		}
		trPrev = tr;
	}

	private static void say(MinecraftClient mc, String msg) {
		if (mc.player != null) {
			mc.player.sendMessage(Text.literal(msg), true);
		}
	}
}
