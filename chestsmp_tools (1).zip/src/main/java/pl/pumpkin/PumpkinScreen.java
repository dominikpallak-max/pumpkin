package pl.pumpkin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.function.Consumer;
import java.util.function.DoubleConsumer;

public class PumpkinScreen extends Screen {

	private static final int W = 220;
	private int labelY1, labelY2;
	private int listening = 0; // 0 nic, 1 killaura, 2 tracery
	private ButtonWidget kaKeyBtn, trKeyBtn;

	public PumpkinScreen() {
		super(Text.literal("Chest SMP Tools"));
	}

	@Override
	protected void init() {
		int x = this.width / 2 - W / 2;
		int y = Math.max(30, this.height / 2 - 124);

		kaKeyBtn = ButtonWidget.builder(keyText(1), b -> {
			listening = 1;
			refreshKeyButtons();
		}).dimensions(x, y, W / 2 - 2, 20).build();
		addDrawableChild(kaKeyBtn);
		trKeyBtn = ButtonWidget.builder(keyText(2), b -> {
			listening = 2;
			refreshKeyButtons();
		}).dimensions(x + W / 2 + 2, y, W / 2 - 2, 20).build();
		addDrawableChild(trKeyBtn);
		y += 24;

		ButtonWidget trBtn = ButtonWidget.builder(trText(), b -> {
			PumpkinMod.tracers = !PumpkinMod.tracers;
			b.setMessage(trText());
		}).dimensions(x, y, W, 20).build();
		addDrawableChild(trBtn);
		y += 24;

		addDrawableChild(new Slider(x, y, W, 20, "Grubość linii", 0.1, 10.0, PumpkinMod.thickness, false,
			v -> PumpkinMod.thickness = (float) v));
		y += 24;

		labelY1 = y;
		y += 10;
		TextFieldWidget nameField = new TextFieldWidget(this.textRenderer, x, y, W, 20, Text.literal("Nazwa armor standa"));
		nameField.setMaxLength(64);
		nameField.setText(PumpkinMod.targetName);
		nameField.setChangedListener((Consumer<String>) s -> PumpkinMod.targetName = s);
		addDrawableChild(nameField);
		y += 28;

		ButtonWidget kaBtn = ButtonWidget.builder(kaText(), b -> {
			PumpkinMod.killaura = !PumpkinMod.killaura;
			b.setMessage(kaText());
		}).dimensions(x, y, W, 20).build();
		addDrawableChild(kaBtn);
		y += 24;

		addDrawableChild(new Slider(x, y, W, 20, "Zasięg (bloki)", 1.0, 4.0, PumpkinMod.kaRange, false,
			v -> PumpkinMod.kaRange = (float) v));
		y += 24;

		addDrawableChild(new Slider(x, y, W, 20, "Opóźnienie (ticki)", 1, 20, PumpkinMod.kaDelay, true,
			v -> PumpkinMod.kaDelay = (int) Math.round(v)));
		y += 24;

		labelY2 = y;
		y += 10;
		TextFieldWidget kaField = new TextFieldWidget(this.textRenderer, x, y, W, 20, Text.literal("Nazwa interaction"));
		kaField.setMaxLength(64);
		kaField.setText(PumpkinMod.kaName);
		kaField.setChangedListener((Consumer<String>) s -> PumpkinMod.kaName = s);
		addDrawableChild(kaField);
		y += 30;

		addDrawableChild(ButtonWidget.builder(Text.literal("Gotowe"), b -> close())
			.dimensions(x, y, W, 20).build());
	}

	private Text keyText(int which) {
		String name = which == 1 ? "KillAura" : "Tracery";
		if (listening == which) return Text.literal(name + ": > nacisnij klawisz <");
		int key = which == 1 ? PumpkinMod.killauraKey : PumpkinMod.tracersKey;
		return Text.literal(name + ": [" + Keybinds.keyName(key) + "]");
	}

	private void refreshKeyButtons() {
		kaKeyBtn.setMessage(keyText(1));
		trKeyBtn.setMessage(keyText(2));
	}

	private static Text trText() {
		return Text.literal("Tracery: " + (PumpkinMod.tracers ? "§aWŁĄCZONE" : "§cWYŁĄCZONE"));
	}

	private static Text kaText() {
		return Text.literal("KillAura (interaction): " + (PumpkinMod.killaura ? "§aWŁĄCZONA" : "§cWYŁĄCZONA"));
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		if (listening != 0 && this.client != null) {
			int key = Keybinds.scanPressed(this.client);
			if (key != Keybinds.NONE) {
				if (key == 259 || key == 261) key = Keybinds.NONE; // Backspace/Delete = usun
				if (listening == 1) PumpkinMod.killauraKey = key;
				else PumpkinMod.tracersKey = key;
				listening = 0;
				PumpkinMod.saveConfig();
				refreshKeyButtons();
			}
		}
		super.render(context, mouseX, mouseY, delta);
		int x = this.width / 2 - W / 2;
		context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 12, 0xFFAA00FF);
		context.drawTextWithShadow(this.textRenderer, Text.literal("Nazwa armor standa (tracery)"), x, labelY1, 0xFFAAAAAA);
		context.drawTextWithShadow(this.textRenderer, Text.literal("Nazwa interaction (puste = każdy)"), x, labelY2, 0xFFAAAAAA);
	}

	@Override
	public void close() {
		PumpkinMod.saveConfig();
		super.close();
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	private static class Slider extends SliderWidget {
		private final String label;
		private final double min, max;
		private final boolean whole;
		private final DoubleConsumer onChange;

		Slider(int x, int y, int w, int h, String label, double min, double max, double current,
			   boolean whole, DoubleConsumer onChange) {
			super(x, y, w, h, Text.empty(), (current - min) / (max - min));
			this.label = label;
			this.min = min;
			this.max = max;
			this.whole = whole;
			this.onChange = onChange;
			updateMessage();
		}

		private double real() {
			double v = min + this.value * (max - min);
			return whole ? Math.round(v) : Math.round(v * 10.0) / 10.0;
		}

		@Override
		protected void updateMessage() {
			double v = real();
			setMessage(Text.literal(label + ": " + (whole ? String.valueOf((int) v) : String.valueOf(v))));
		}

		@Override
		protected void applyValue() {
			onChange.accept(real());
		}
	}
}
