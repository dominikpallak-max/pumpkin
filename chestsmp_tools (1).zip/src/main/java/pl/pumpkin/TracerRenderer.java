package pl.pumpkin;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class TracerRenderer {

	private static final int R = 170, G = 0, B = 255, A = 255;
	private static final int TEXT_COLOR = 0xFFAA00FF;
	private static final int FULL_LIGHT = 0xF000F0;
	private static final double PIXEL = 0.0013;

	private TracerRenderer() {}

	public static void init() {
		WorldRenderEvents.BEFORE_TRANSLUCENT.register(TracerRenderer::render);
	}

	private static boolean matches(Entity e) {
		if (!(e instanceof ArmorStandEntity)) return false;
		return e.getName().getString().toLowerCase(Locale.ROOT)
			.contains(PumpkinMod.targetName.toLowerCase(Locale.ROOT));
	}

	private static void render(WorldRenderContext context) {
		if (!PumpkinMod.tracers) return;
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.world == null || mc.player == null) return;

		float tick = mc.getRenderTickCounter().getTickProgress(false);

		List<Entity> targets = new ArrayList<>();
		for (Entity e : mc.world.getEntities()) {
			if (matches(e)) targets.add(e);
		}
		if (targets.isEmpty()) return;

		Vec3d cam = context.worldState().cameraRenderState.pos;
		Quaternionf rot = context.worldState().cameraRenderState.orientation;
		MatrixStack matrices = context.matrices();
		VertexConsumerProvider consumers = context.consumers();

		Vector3f fwd = new Vector3f(0f, 0f, -1f).rotate(rot);
		Vec3d start = cam.add(fwd.x, fwd.y, fwd.z);

		matrices.push();
		matrices.translate(-cam.x, -cam.y, -cam.z);

		VertexConsumer quads = consumers.getBuffer(RenderLayers.textBackgroundSeeThrough());
		MatrixStack.Entry entry = matrices.peek();
		double hw1 = 0.5 * PumpkinMod.thickness * PIXEL * start.distanceTo(cam);

		for (Entity e : targets) {
			Vec3d end = e.getLerpedPos(tick).add(0, e.getHeight() / 2.0, 0);
			Vec3d dir = end.subtract(start);
			Vec3d mid = start.add(end).multiply(0.5);

			Vec3d side = dir.crossProduct(cam.subtract(mid));
			if (side.lengthSquared() < 1.0E-8) side = dir.crossProduct(new Vec3d(0, 1, 0));
			if (side.lengthSquared() < 1.0E-8) continue;
			side = side.normalize();

			double hw2 = 0.5 * PumpkinMod.thickness * PIXEL * end.distanceTo(cam);

			Vec3d a1 = start.add(side.multiply(hw1));
			Vec3d a2 = start.subtract(side.multiply(hw1));
			Vec3d b1 = end.add(side.multiply(hw2));
			Vec3d b2 = end.subtract(side.multiply(hw2));

			vert(quads, entry, a1); vert(quads, entry, a2); vert(quads, entry, b2); vert(quads, entry, b1);
			vert(quads, entry, b1); vert(quads, entry, b2); vert(quads, entry, a2); vert(quads, entry, a1);
		}

		TextRenderer tr = mc.textRenderer;
		Vec3d me = mc.player.getLerpedPos(tick);
		for (Entity e : targets) {
			Vec3d ep = e.getLerpedPos(tick);
			double dist = me.distanceTo(ep);
			Vec3d tp = ep.add(0, e.getHeight() + 0.4, 0);
			Text text = Text.literal(e.getName().getString() + " §7[" + String.format(Locale.ROOT, "%.1f", dist) + "m]");

			matrices.push();
			matrices.translate(tp.x, tp.y, tp.z);
			matrices.multiply(rot);
			matrices.scale(0.025f, -0.025f, 0.025f);
			float w = -tr.getWidth(text) / 2.0f;
			tr.draw(text, w, 0f, TEXT_COLOR, false, matrices.peek().getPositionMatrix(), consumers,
				TextRenderer.TextLayerType.SEE_THROUGH, 0, FULL_LIGHT);
			matrices.pop();
		}

		matrices.pop();
	}

	private static void vert(VertexConsumer vc, MatrixStack.Entry entry, Vec3d p) {
		vc.vertex(entry, (float) p.x, (float) p.y, (float) p.z).color(R, G, B, A).light(FULL_LIGHT);
	}
}
