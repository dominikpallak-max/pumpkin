package pl.upiorny.drop;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.*;
import java.util.*;

/** Config: .minecraft/config/upiorny_drop.json  (mozesz edytowac drop kazdej skrzyni) */
public class DropConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("upiorny_drop.json");

    public boolean enabled = true;
    /** klucz = poziom skrzyni ("1","2","3"), wartosc = linie dropu (kody &a, &b itd. dzialaja) */
    public Map<String, List<String>> drops = defaults();

    public static DropConfig INSTANCE = new DropConfig();

    public static void load() {
        try {
            if (Files.exists(PATH)) {
                DropConfig c = GSON.fromJson(Files.readString(PATH), DropConfig.class);
                if (c != null) {
                    if (c.drops == null) c.drops = defaults();
                    INSTANCE = c;
                    return;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        INSTANCE = new DropConfig();
        save();
    }

    public static void save() {
        try {
            Files.writeString(PATH, GSON.toJson(INSTANCE));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Map<String, List<String>> defaults() {
        Map<String, List<String>> m = new LinkedHashMap<>();
        m.put("1", new ArrayList<>(List.of(
            "&b Diamentowy miecz (Ostrosc IV)",
            "&b Diamentowy helm (Ochrona III)",
            "&b Diamentowe narzedzia i zbroja",
            "&e Zaklete zlote jablko",
            "&b Diament x64",
            "&a Szmaragd x64",
            "&f Obsydian x64",
            "&d Zaklinacz Przedmiotow",
            "&f Fajerwerk",
            "&7 Ksiazki, spawnery, bloki i inne"
        )));
        m.put("2", new ArrayList<>(List.of(
            "&d Ametystowy Luk (Moc VI, Plomien, Uderzenie III)",
            "&d Ametystowe narzedzia i zbroja",
            "&c Dodatkowe Zycie",
            "&d Krysztal Ametystu",
            "&b Diamentowe przedmioty",
            "&7 Ksiazki, bloki i inne"
        )));
        m.put("3", new ArrayList<>(List.of(
            "&d Ametystowe narzedzia i zbroja",
            "&f Szkielet (spawner)",
            "&b EnderChest Booster",
            "&c Anty-Web",
            "&6 Zlote przedmioty",
            "&7 Ksiazki, bloki i inne"
        )));
        return m;
    }
}
