package pl.upiorny.drop;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.List;
import java.util.regex.*;

public class UpiornyDropClient implements ClientModInitializer {
    // np. "Upiorna Skrzynia (Poziom: 2)"
    private static final Pattern CHEST = Pattern.compile("Upiorna Skrzynia.*?Poziom:?\\s*(\\d+)", Pattern.CASE_INSENSITIVE);

    @Override
    public void onInitializeClient() {
        DropConfig.load();

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("minecraftserver").executes(ctx -> {
                MinecraftClient mc = ctx.getSource().getClient();
                mc.send(() -> mc.setScreen(new ToggleScreen())); // po zamknieciu czatu
                return 1;
            })));

        ItemTooltipCallback.EVENT.register((stack, context, type, lines) -> {
            if (!DropConfig.INSTANCE.enabled || stack.isEmpty()) return;
            Matcher m = CHEST.matcher(stack.getName().getString());
            if (!m.find()) return;
            List<String> drop = DropConfig.INSTANCE.drops.get(m.group(1));
            if (drop == null || drop.isEmpty()) return;

            // wstaw przed linia z ID (minecraft:pumpkin), jesli jest (F3+H)
            int idx = lines.size();
            for (int i = 1; i < lines.size(); i++) {
                if (lines.get(i).getString().startsWith("minecraft:")) { idx = i; break; }
            }
            lines.add(idx++, Text.literal(""));
            lines.add(idx++, Text.literal("\u00a76Drop ze skrzyni (Poziom " + m.group(1) + "):"));
            for (String s : drop) lines.add(idx++, Text.literal(s.replace('&', '\u00a7')));
        });
    }
}
