package pl.upiorny.drop;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class ToggleScreen extends Screen {
    public ToggleScreen() {
        super(Text.literal("Upiorny Drop"));
    }

    private Text label() {
        boolean on = DropConfig.INSTANCE.enabled;
        return Text.literal("Pokazuj drop: ").append(
            Text.literal(on ? "WLACZONE" : "WYLACZONE").formatted(on ? Formatting.GREEN : Formatting.RED));
    }

    @Override
    protected void init() {
        addDrawableChild(ButtonWidget.builder(label(), b -> {
            DropConfig.INSTANCE.enabled = !DropConfig.INSTANCE.enabled;
            DropConfig.save();
            b.setMessage(label());
        }).dimensions(width / 2 - 80, height / 2 - 10, 160, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Zamknij"), b -> close())
            .dimensions(width / 2 - 50, height / 2 + 20, 100, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 35, 0xFFFFFFFF);
    }
}
